import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import medfilt, savgol_filter


# Load the data
file_name = "log_146withDegree.csv"
data = pd.read_csv(file_name, delimiter=',', decimal='.')

# Ensure proper column names
data.columns = ['Timestamp', 'Suspension1', 'Suspension2', 'Suspension3', 'Suspension4',
                'Steering', 'RPM_FrontRight', 'RPM_FrontLeft', 'RPM_RearRight', 'RPM_RearLeft',
                'Theta', 'Derajat']

# Zero out all outliers above 5000 in RPM columns
data.loc[data['RPM_FrontRight'] > 5000, 'RPM_FrontRight'] = 0
data.loc[data['RPM_FrontLeft'] > 5000, 'RPM_FrontLeft'] = 0
data.loc[data['RPM_RearRight'] > 5000, 'RPM_RearRight'] = 0
data.loc[data['RPM_RearLeft'] > 5000, 'RPM_FrontLeft'] = 0
# Scale 'Derajat'
data['Derajat'] = data['Derajat'] * 10

# DONT USE THIS
def flatten_sudden_jumps(series, threshold=500, window=10):
    smoothed_series = series.copy()
    for i in range(1, len(series) - 1):
        if abs(series[i] - series[i - 1]) > threshold: 
            start = max(0, i - window)
            end = min(len(series), i + window + 1)
            smoothed_series[start:end] = np.median(series[start:end]) 
    return smoothed_series

def check_direction(deg_series):
    total = deg_series.sum()
    if total < 0:
        print("CCW")
    elif total > 0:
        print("CW")
    else:
        print("No net rotation")

def print_avg_metrics(data, start_idx, end_idx):
    if start_idx < 0 or end_idx >= len(data):
        print("Error: Index out of range.")
        return

    subset = data.iloc[start_idx:end_idx + 1]  # Extract the relevant portion

    # Compute non-zero averages for speed
    avg_kmph_fr = subset['KMPH_FrontRight'][subset['KMPH_FrontRight'] > 0].mean()
    avg_kmph_fl = subset['KMPH_FrontLeft'][subset['KMPH_FrontLeft'] > 0].mean()

    # Compute non-zero averages for RPM
    avg_rpm_fr = subset['CMA_RPM_FrontRight'][subset['CMA_RPM_FrontRight'] > 0].mean()
    avg_rpm_fl = subset['CMA_RPM_FrontLeft'][subset['CMA_RPM_FrontLeft'] > 0].mean()

    print(f"Average KMPH_FrontRight (non-zero) from index {start_idx} to {end_idx}: {avg_kmph_fr:.2f}")
    print(f"Average KMPH_FrontLeft (non-zero) from index {start_idx} to {end_idx}: {avg_kmph_fl:.2f}")
    print(f"Average CMA_RPM_FrontRight (non-zero) from index {start_idx} to {end_idx}: {avg_rpm_fr:.2f}")
    print(f"Average CMA_RPM_FrontLeft (non-zero) from index {start_idx} to {end_idx}: {avg_rpm_fl:.2f}")
    print("\n")


#Median Filter
# Apply the median filter first
N = 17  # Kernel size
data['CMA_RPM_FrontRight'] = medfilt(data['RPM_FrontRight'], kernel_size=N)
data['CMA_RPM_FrontLeft'] = medfilt(data['RPM_FrontLeft'], kernel_size=N)

# Apply the custom spike-smoothing filter
# data['CMA_RPM_FrontRight'] = flatten_sudden_jumps(data['CMA_RPM_FrontRight'])
# data['CMA_RPM_FrontLeft'] = flatten_sudden_jumps(data['CMA_RPM_FrontLeft'])

# Apply Savitzky-Golay filter for final smoothing
data['CMA_RPM_FrontRight'] = savgol_filter(data['CMA_RPM_FrontRight'], window_length=11, polyorder=2)
data['CMA_RPM_FrontLeft'] = savgol_filter(data['CMA_RPM_FrontLeft'], window_length=11, polyorder=2)

data['KMPH_FrontRight'] = data['CMA_RPM_FrontRight'] * 0.0766
data['KMPH_FrontLeft'] = data['CMA_RPM_FrontLeft'] * 0.0766


bins = range(1, 5101, 100)
counts_fr, edges_fr = np.histogram(data['CMA_RPM_FrontRight'], bins=bins)
print("RPM_FrontRight counts in 100-RPM increments:")
for i in range(len(counts_fr)):
    print(f"{edges_fr[i]}–{edges_fr[i+1]} : {counts_fr[i]}")

counts_fl, edges_fl = np.histogram(data['CMA_RPM_FrontLeft'], bins=bins)
print("\nRPM_FrontLeft counts in 100-RPM increments:")
for i in range(len(counts_fl)):
    print(f"{edges_fl[i]}–{edges_fl[i+1]} : {counts_fl[i]}")
bin_centers_fr = (edges_fr[:-1] + edges_fr[1:]) / 2
mean_rpm_fr = np.sum(counts_fr * bin_centers_fr) / np.sum(counts_fr)
print(f"Average RPM_FrontRight (whole dataset excluding zero): {mean_rpm_fr}")

bin_centers_fl = (edges_fl[:-1] + edges_fl[1:]) / 2
mean_rpm_fl = np.sum(counts_fl * bin_centers_fl) / np.sum(counts_fl)
print(f"Average RPM_FrontLeft (whole dataset excluding zero): {mean_rpm_fl}")
print("\n")
# check_direction(data['Derajat'])
print_avg_metrics(data, 1, len(data)-1)
print_avg_metrics(data, 200, 1500)
# print_avg_metrics(data, 4266, 5628)
# print_avg_metrics(data, 5795, 7100)

# print_avg_speed(data, 5790, 7150)

plt.figure()
plt.bar(edges_fr[:-1], counts_fr, width=100, alpha=0.5, label='CMA_RPM_FrontRight')
plt.bar(edges_fl[:-1], counts_fl, width=100, alpha=0.5, label='CMA_RPM_FrontLeft')
plt.xlabel('RPM Range')
plt.ylabel('Count')
plt.title(f'{file_name} Histogram of RPM in 100-RPM increments starting from 1')
plt.legend()
plt.show()

# Plot the data
plt.figure(figsize=(12, 6))
plt.plot(data.index, data['RPM_FrontRight'], label='RPM_FrontRight (Raw)', color='orange', alpha=0.2)
plt.plot(data.index, data['CMA_RPM_FrontRight'], label='CMA RPM_FrontRight', color='red',alpha=0.8)
plt.plot(data.index, data['RPM_FrontLeft'], label='RPM_FrontLeft (Raw)', color='blue', alpha=0.2)
plt.plot(data.index, data['CMA_RPM_FrontLeft'], label='CMA RPM_FrontLeft', color='purple',alpha=0.8)
plt.plot(data.index, data['Derajat'], label='Derajat CW is increment', color='green', alpha=1)
plt.plot(data.index, data['KMPH_FrontRight'],linestyle='--' , label='KMPH_FrontRigh', color='orange',alpha=0.8)
plt.plot(data.index, data['KMPH_FrontLeft'],linestyle='--', label='KMPH_FrontLeft', color='yellow',alpha=0.8)
plt.axhline(y=0, color='red', linestyle='--', alpha=0.5)
plt.xlabel('Index')
plt.ylabel('RPM')
plt.title(f'{file_name} RPM Data with Centered Moving Average')
plt.legend()
plt.show()
